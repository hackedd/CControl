/**********************************************************

   C-Control Betriebssystem, 68HC05B6

   Copyright (c) Conrad Electronic GmbH, Hirschau

   Datei:   timing.c
   Inhalt:  Funktionen zum Systemtiming und DCF77-Empfang
            (siehe auch interrpt.as)

**********************************************************/

#include "timing.h"
#include "portio.h"
#include "6805\68hc05b6.h"
#include "6805\bits.h"
#include <intrpt.h>

 
// Echtzeituhr
char near hour;
char near min;
char near sec;
char near dayoftheweek;
char near day;
char near month;
char near year;


#define DCFGAPWIDTH    1100
#define DCFHIBITWIDTH  150               // eigentlich 200 ms!
#define DCFLOBITWIDTH  50                // eigentlich 100 ms!
#define DCFMAXBITWIDTH 900
#define DCFMAXGAPWIDTH 2000

// 4 MHz -> 500 Timerticks pro ms
#define TICKS_PER_MS 500

#define TIMERES 20
#define TICKS			10000
#define SLOW_TICKS		625

//#define TIMERES 4
//#define TICKS			2000
//#define SLOW_TICKS		125



// Pufferstruktur fuer DCF77-Empfang
typedef struct
        {
	  char year;
	  char month;
	  char day;
	  char dayw;
	  char hour;
	  char min;
        } DCFSTRUCT;


// zwei DCF77-Puffer
DCFSTRUCT near dcfnew;
DCFSTRUCT near dcfold;


unsigned char near flags;


const unsigned char MAXDAYS[] =
   {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

const unsigned char TIMEADD[] = {1, 2, 4, 8, 10, 20, 40, 80};

static struct {
                int icf1 :1;
                int ocf1 :1;
                int tof  :1;
                int icf2 :1;
                int ocf2 :1;
              } tmrstat @ TMRSTAT;


static struct {
                int icie  :1;
                int ocie  :1;
                int toie  :1;
                int folv2 :1;
                int folv1 :1;
                int olvl2 :1;
                int iedg1 :1;
                int olvl1 :1;
              } tmrctrl @ TMRCTRL;


WORDSTRUCT counter @ COUNTHI;
WORDSTRUCT comp1 @ COM1HI;
WORDSTRUCT comp2 @ COM2HI;

unsigned char cap1lo @ CAP1LO;
unsigned char cap2lo @ CAP2LO;


// Zaehler
unsigned int near timer;		// fuer Anwenderprogramm
unsigned int near waitcnt;
unsigned int near userticks;		// fuer User-Frequenzgenerator
unsigned int near pulsecnt;		// Pulsezaehler am DCF-Eingang (1 sec)
unsigned int near pulsecnt2;		// Pulsezaehler am DCF-Eingang (1 sec)
unsigned int near freqhz;		// Frequenz am DCF77
unsigned int near freqhz2;		// Frequenz an TCAP2

unsigned int near clockMsCnt;	// fuer Echtzeituhr
unsigned int near dcfMsCnt;		// f�r Pulsweitenmessung beim DCF77-Empfang
unsigned char near dcfBitCnt;	// Bitzaehler beim DCF77-Empfang


// lokale Prototypen
void DCF77LoHi ( void );
void DCF77HiLo ( void );
void ReadyForNextFrame ( void );
void AddBit ( void );
void CopyTime ( void );
void Clock ( void );

WORDSTRUCT near nextcompare;


//------------------
  void InitTiming ()
//------------------
{
  // Echtzeituhr initialisieren	
  hour = 0;
  min = 0;
  sec = 0;
  dayoftheweek = 3;
  day = 1;
  month = 1;    
  year = 97;    
  clockMsCnt = 0;

  // DCF77-Empfang initialisieren
  dcfMsCnt = 0;
  ReadyForNextFrame();

  dcfold.year = 0;
  dcfold.month = 0; 
  dcfold.day = 0;
  dcfold.dayw = 0;
  dcfold.hour = 0;
  dcfold.min = 0;
  ClrSynchFlag();
  ClrDCF77ValidFlag();
  
  ACTIVATE_DCF_LED;
  SET_DCF_LED_OFF;

  timer = 0;
  waitcnt = 0;
  pulsecnt = 0;
  pulsecnt2 = 0;
  freqhz = 0;
  freqhz2 = 0;
 
  // Timer Interrupts einschalten
  tmrctrl.icie = 1;
  tmrctrl.ocie = 1;

  asm("bset 5,9"); // ADC einschalten

  userticks = 0;
  tmrctrl.olvl1 = 0;
}


//----------------------
  void HandleSysTimer ()
//----------------------
{
  // n�chsten Output Compare berechnen
  if ( bIsSlow )
    nextcompare.word = comp2.word + SLOW_TICKS;
  else
    nextcompare.word = comp2.word + TICKS;
    
  comp2.byte.hi = nextcompare.byte.hi;
  comp2.byte.lo = nextcompare.byte.lo;

  // Millisekunden fuer DCF77 zaehlen
  // und Test, ob DCF-Signal noch da ist 
  dcfMsCnt += TIMERES;
  if ( dcfMsCnt > DCFMAXGAPWIDTH ) 
  {
    ClrSynchFlag();
    SET_DCF_LED_OFF; 
  }	    

  // Echtzeituhr
  clockMsCnt += TIMERES;

  if ( clockMsCnt == 1000 )
  {
    clockMsCnt = 0;
    Clock();                        // Uhr 1 sec weiterschalten
  }

  // User Timer
  timer += 1;

  if ( waitcnt )
    waitcnt -= 1;  

  // Sytempuls ausgeben
  tmrctrl.olvl2 ^= 1;
}


//-----------------------
  void HandleUserTimer ()
//-----------------------
{
  nextcompare.word = comp1.word + userticks;
  comp1.byte.hi = nextcompare.byte.hi;
  comp1.byte.lo = nextcompare.byte.lo;

  // Userpuls ausgeben
  if ( userticks )
    tmrctrl.olvl1 ^= 1;
  else
    tmrctrl.olvl1 = 0;
}


//-----------------
  void DCF77LoHi ()
//-----------------
{
  // wenn Lo-Impuls nicht zu lang, dann auf Bit testen
  if ( dcfMsCnt < DCFMAXBITWIDTH )
  {
    // ein Hibit	    
    if ( dcfMsCnt >= DCFHIBITWIDTH ) AddBit();
    
    // Impuls lang genug, dann Bit
    if ( dcfMsCnt >= DCFLOBITWIDTH ) dcfBitCnt++;

    // sonst zu kurz lo = Stoerimpuls -> ignorieren
  }

  // Lo-Impuls zu lang -> schwerer Fehler
  else   
  {
    ReadyForNextFrame();
    ClrSynchFlag();
  }

  dcfMsCnt = 0;
  // blink if out of synch	    
  if ( !bIsSynchronized ) SET_DCF_LED_OFF; 
}

//-----------------------
  void DCF77HiLo ( void )
//-----------------------
{
  static char deltamin;

  pulsecnt++;
  
  // blink if out of synch
  if ( !bIsSynchronized ) SET_DCF_LED_ON;

  // Synchronisation nach der 59. Sekunde
  if ( dcfMsCnt > DCFGAPWIDTH )
  {
    if ( dcfMsCnt < DCFMAXGAPWIDTH )
    {
      deltamin = dcfnew.min - dcfold.min;
      // wenn gueltig, Zeit uebernehmen;
      // nur gueltig, wenn Teile des empfangenen Rahmens mit dem
      // vorherigen uebereinstimmen und eine Minute weiter
      if (  ( dcfBitCnt == (unsigned char)59 )
          && (dcfnew.year == dcfold.year) 
          && (dcfnew.month == dcfold.month)
          && (dcfnew.day == dcfold.day) 
          && (dcfnew.dayw == dcfold.dayw)
          && (dcfnew.hour == dcfold.hour) 
          && ( deltamin == (unsigned char)1 )
         )
      {
        CopyTime();
        SET_DCF_LED_ON;
        SetSynchFlag(); // synch-flag
        SetDCF77ValidFlag();
      }
      else
      {
        SET_DCF_LED_OFF;
        ClrSynchFlag(); // synch-flag
      } 

      // neu wird zu alt
      dcfold.year = dcfnew.year;
      dcfold.month = dcfnew.month; 
      dcfold.day = dcfnew.day;
      dcfold.dayw = dcfnew.dayw;
      dcfold.hour = dcfnew.hour;
      dcfold.min = dcfnew.min;
    }
    // Hi-Impuls zu lang -> schwerer Fehler
    else
    {
      SET_DCF_LED_OFF;
      ClrSynchFlag(); // synch-flag
    } 
    ReadyForNextFrame();
  }
  dcfMsCnt = 0;
}


//--------------
  void AddBit ()
//--------------
{
  if ( (dcfBitCnt >= 21) && (dcfBitCnt <= 27) )
    dcfnew.min += TIMEADD[dcfBitCnt-21];

  else if ( (dcfBitCnt >= 29) && (dcfBitCnt <= 34) )
    dcfnew.hour += TIMEADD[dcfBitCnt-29];

  else if ( (dcfBitCnt >= 36) && (dcfBitCnt <= 41) )
    dcfnew.day += TIMEADD[dcfBitCnt-36];

  else if ( (dcfBitCnt >= 42) && (dcfBitCnt <= 44) )
    dcfnew.dayw += TIMEADD[dcfBitCnt-42];

  else if ( (dcfBitCnt >= 45) && (dcfBitCnt <= 49) )
    dcfnew.month += TIMEADD[dcfBitCnt-45];

  else if ( (dcfBitCnt >= 50) && (dcfBitCnt <= 57) )
    dcfnew.year += TIMEADD[dcfBitCnt-50];
}


//----------------
  void CopyTime ()
//----------------
{
  year = dcfnew.year;
  month = dcfnew.month;
  day = dcfnew.day;
  dayoftheweek = dcfnew.dayw;
  hour = dcfnew.hour;
  min = dcfnew.min;
  sec = 0;
}


//-------------------------
  void ReadyForNextFrame ()
//-------------------------
{
  dcfnew.year = 0;
  dcfnew.month = 0; 
  dcfnew.day = 0;
  dcfnew.dayw = 0;
  dcfnew.hour = 0;
  dcfnew.min = 0;
  dcfBitCnt = 0;
}


//-------------
  void Clock ()
//-------------
{
  static char lastdayofthemonth;
  static char yeartest;

  freqhz = pulsecnt;
  pulsecnt = 0;
  freqhz2 = pulsecnt2;
  pulsecnt2 = 0;

  sec++;

  if ( sec == 60 )
  {
    sec = 0;
    min++;

    if ( min == 60 )
    {
      min = 0;	  
      hour++;

      if ( hour == 24 )
      {
        hour = 0; 
        day++;
        dayoftheweek++;

        if ( dayoftheweek == 8 )
          dayoftheweek = 0;           // Wochentag 0 = Sonntag
    
        lastdayofthemonth = MAXDAYS[month];

        if ( month == 2 )            // Februar
        {
          yeartest = year / 4;
          yeartest = year * 4;
          if ( year == yeartest )       // Schaltjahr
            lastdayofthemonth = 29;
        }

        if ( day > lastdayofthemonth )
        {
          day = 1;	    
          month++;

          if ( month == 13 )
          {
            month = 1;  
	    year++;

	    if ( year == 100 )
	      year = 0;
          }
        }
      }
    }
  }
}


//-----------------------------
  void Wait ( unsigned int ms )
//-----------------------------
{
  di();
    waitcnt = ms;
  ei();

  while ( waitcnt )
    asm("WAIT");
}


//---------------------------
  void SetSlowModeOn ( void )
//---------------------------
{
  di();
  flags |= 32;
  asm("BSET 1,0x0C");
  ei();
}

//----------------------------
  void SetSlowModeOff ( void )
//----------------------------
{
  di();
  flags &= ~32;
  asm("BCLR 1,0x0C");
  ei();
}


//----------------------------------------
  void SetUserTicks ( unsigned int ticks )
//----------------------------------------
{
  di();

  userticks = ticks;

  if ( userticks )
  {
    if ( bIsSlow )
      userticks /= 16;
      
    ticks = counter.word;
    nextcompare.word = ticks + userticks;
    comp1.word = nextcompare.word; 
    tmrctrl.olvl1 = 1;
  }

  else
    tmrctrl.olvl1 = 0;
  
  ei();
}


//------------------------------
  unsigned int GetTimer ( void )
//------------------------------
{
#asm	
  sei
  ldx _timer 
  lda _timer+1
  cli
#endasm
}

//-------------------------------
  unsigned int GetFreqHz ( void )
//-------------------------------
{
#asm	
  sei
  ldx _freqhz
  lda _freqhz+1
  cli
#endasm
}


//--------------------------------
  unsigned int GetFreqHz2 ( void )
//--------------------------------
{
#asm	
  sei
  ldx _freqhz2
  lda _freqhz2+1
  cli
#endasm
}  

