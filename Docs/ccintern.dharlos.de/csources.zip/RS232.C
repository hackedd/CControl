/**********************************************************

   C-Control Betriebssystem, 68HC05B6

   Copyright (c) Conrad Electronic GmbH, Hirschau

   Datei:   rs232.c
   Inhalt:  RS232-Schnittstelle

**********************************************************/

#include "rs232.h"
#include "host.h"
#include "6805\68hc05b6.h"
#include "portio.h"
#include "timing.h"
#include <intrpt.h>

static unsigned char sciBaud @ SCI_BAUD;
static unsigned char sciData @ SCI_DATA;


#define RXBUFLEN 8
unsigned char near rxBuf[RXBUFLEN];
unsigned char near rxGetIndex;
unsigned char near rxPutIndex;
unsigned char near rxCount;



// SCI control

unsigned char sccr1 @ SCI_SCCR1;
unsigned char sccr2 @ SCI_SCCR2;


/* Serial Communications Status Register */

union {
		  unsigned char all;
		  struct  {
						int TDRE: 1;
						int TC: 1;
						int RDRF: 1;
						int IDLE: 1;
						int OR: 1;
						int NF: 1;
						int FE: 1;
						int : 1;
					 } bit;
		} scsr @ SCI_SCSR;

/*
	9600 Baud fuer Sender und Empfaenger bei 4 MHz Oszillator:
	Vorteiler 13, Teiler 1
*/

#define DEFAULT_BAUD 0xC0


/* Initialization */

//-------------------
  void RS232_Setup ()
//-------------------
{
  RS232_EmptyRX();
  RS232_SetBaud(DEFAULT_BAUD);

  sccr1 = 0;
  sccr2 = 0x2C; // RIE, TE, RE ein

  // RTS-Leitung als output
  asm("bset 6,4");
  RTS();
}

//-----------------------------------------
  void RS232_SetBaud ( unsigned char rate )
//-----------------------------------------
{
  sciBaud = rate;	
}


//-------------------------------------------
  void RS232_WriteByte ( unsigned char byte )
//-------------------------------------------
{
#asm
txwait	brclr	6,16,txwait
	stx	17
#endasm
}



// Handler fuer die serielle Schnittstelle


//---------------------------
  void interrupt HandleSCI ()
//---------------------------
{
  unsigned char ok = scsr.bit.RDRF && !(scsr.bit.NF || scsr.bit.FE);
  unsigned char byte = sciData;

  // kein noise oder framing error
  if ( ok && (rxCount < RXBUFLEN) ) 
  {
    rxBuf[rxPutIndex] = byte;		// byte im Puffer speichern
    rxPutIndex++;			// Speicherindex erhoehen
    rxPutIndex %= RXBUFLEN;
    rxCount++;

    if ( bIsRtsCtsEnabled ) NotRTS();
  }
}


//------------------------------
  unsigned char RS232_GetByte ()
//------------------------------
{
  unsigned char byte;

  RTS();
  
  // warten auf ein Byte
  while ( !RS232_IsByteAvail() );

  byte = rxBuf[rxGetIndex];
  rxGetIndex++;
  rxGetIndex %= RXBUFLEN;
  rxCount--;
  
  return byte;
}


//----------------------------------
  unsigned char RS232_IsByteAvail ()
//----------------------------------
{
  RTS();
  
  return ( rxCount != 0 );
}


//----------------------------
  unsigned char RS232_IsCTS ()
//----------------------------
{
#asm
	clra	
	brset	7,0,notcts
	inca
notcts	rts	
#endasm
}


//---------------------
  void RS232_EmptyRX ()
//---------------------
{
  rxPutIndex = 0;
  rxGetIndex = 0;	
  rxCount = 0;
}


const int div[] = { 10000, 1000, 100, 10, 1 };

//----------------------------------------
  void RS232_SendValueAsText ( int value )
//----------------------------------------
{
  unsigned char bDoSendZeros = 0;
  unsigned char i;

  if ( value == 0 )
  {
    RS232_WriteByte('0');
    return;
  }
  
  if ( value < 0 )
  {
    RS232_WriteByte('-');
    value = -value;
  }

  for ( i=0; i < 5; i++ )
  {
    if ( value >= div[i] )
    {
      RS232_WriteByte('0' + value/div[i]);
      bDoSendZeros = 1;
    }  
    else if ( bDoSendZeros )
    {
      RS232_WriteByte('0');
    }

    value %= div[i];
  }
}


