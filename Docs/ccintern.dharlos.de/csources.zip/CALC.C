/**********************************************************

   C-Control Betriebssystem, 68HC05B6

   Copyright (c) Conrad Electronic GmbH, Hirschau

   Datei:   calc.c
   Inhalt:  Header fuer calc.c

**********************************************************/


#include "calc.h"
#include "timing.h"

#define TRUE 0xFFFF
#define FALSE 0
 

union { unsigned char byte[NUM_USERBYTES];
        int           word[NUM_USERBYTES/2]; } near userdata;
  

int near A;
int near B;
int near C;
int near D;
int near E;
int near F;
int near G;


unsigned int near R;


void NumPush ( void );
void NumPop ( void );

  
// *** Initialisierungen *** 

//-----------------------
  void ClearRegs ( void )
//-----------------------
{
  A = B = C = D = E = F = G = 0;
}

//---------------------
  void NumPush ( void )
//---------------------
{
  G = F;
  F = E;
  E = D;
  D = C;
  C = B;
  B = A;	 
}

//--------------------
  void NumPop ( void ) 
//--------------------
{
  // A ergibt sich aus Berechnung mit B
  B = C;
  C = D;
  D = E;
  E = F;
  F = G;
}

//-----------------------
  void ClearData ( void )
//-----------------------
{
  unsigned char i;

  for ( i = 0; i < NUM_USERBYTES; i++ )
    userdata.byte[i] = 0;
}


// *** Speicheroperationen ***

//---------------------------------
  void LoadBit ( unsigned char nr )
//---------------------------------
{
  unsigned char i = nr / 8;           // Byteindex
  unsigned char bit = nr % 8;         // Bitindex
  unsigned char mask = 1 << bit;      // Testmaske
  mask &= userdata.byte[i];

  NumPush();
  if ( mask ) 
    A = TRUE;
  else 
    A = FALSE;
}

//---------------------------------
  void LoadByte ( unsigned char i )
//---------------------------------
{
  NumPush();
  A = userdata.byte[i];	
}

//---------------------------------
  void LoadWord ( unsigned char i )
//---------------------------------
{
  NumPush();
  A = userdata.word[i];	
}

//---------------------------------------
  void LoadBitImm ( unsigned char value )
//---------------------------------------
{
  NumPush();
  if ( value ) 
    A = TRUE;
  else 
    A = FALSE;
}

//----------------------------------------
  void LoadByteImm ( unsigned char value )
//----------------------------------------
{
  NumPush();
  A = value;	
}

//------------------------------
  void LoadWordImm ( int value )
//------------------------------
{
  NumPush();
  A = value;	
}

//----------------------------------
  void StoreBit ( unsigned char nr )
//----------------------------------
{
  unsigned char i = nr / 8;           // Byteindex
  unsigned char bit = nr % 8;         // Bitindex
  unsigned char mask = 1 << bit;      // Testmaske

  if ( A )
    userdata.byte[i] |= mask;
  else
    userdata.byte[i] &= ~mask;

}

//----------------------------------
  void StoreByte ( unsigned char i )
//----------------------------------
{
  userdata.byte[i] = (unsigned char)	A; 
}

//----------------------------------
  void StoreWord ( unsigned char i )
//----------------------------------
{
  userdata.word[i] = A;	
}


// *** logische Verknuepfungen ***

//-----------------
  void Not ( void )
//-----------------
{
  A ^= 0xFFFF;
}
	
//-----------------
  void And ( void )
//-----------------
{
  A = B & A;	
  NumPop();
}

//-----------------
  void Nand( void )
//-----------------
{
  And();
  Not();	
}

//----------------
  void Or ( void )
//----------------
{
  A = B | A;
  NumPop();	
}

//-----------------
  void Nor ( void )
//-----------------
{
  Or();
  Not();	
}

//-----------------
  void Xor ( void )
//-----------------
{
  A = B ^ A;
  NumPop();	
}

//-----------------
  void Shl ( void )
//-----------------
{
  A = B << (unsigned char) A;
  NumPop();	
}

//-----------------
  void Shr ( void )
//-----------------
{
  A = B >> (unsigned char) A;	
  NumPop();
}


// *** mathematische Berechnungen ***

//-----------------
  void Neg ( void )
//-----------------
{
  A = -A;
}

//-----------------
  void Add ( void )
//-----------------
{
  A = B + A;	
  NumPop();
}


//-----------------
  void Sub ( void )
//-----------------
{
  A = B - A;
  NumPop();
}


//-----------------
  void Mul ( void )
//-----------------
{
  A = B * A;
  NumPop();
}


//-----------------
  void Div ( void )
//-----------------
{
  A = B / A;
  NumPop();
}


//-----------------
  void Mod ( void )
//-----------------
{
  A = B % A;
  NumPop();
}


//-----------------
  void Abs ( void )
//-----------------
{
  if ( A < 0 ) A = -A;	
}


//-----------------
  void Sgn ( void )
//-----------------
{
  if ( A < 0 ) A = -1;
  if ( A > 0 ) A = 1;
}


//-----------------
  void Sqr ( void )
//-----------------
{
  unsigned char i;
  int result;

  if (A == 0) return;

  if ( A < 0 )
  {
    A = 0;
    return;
  }

  result = 1;

  for (i = 0; i < 10; i++)
    result = (result + A / result) / 2;

  A = result;
}


//-----------------------
  void Randomize ( void )
//-----------------------
{
  if ( A == 0 )
    R = GetTimer();	
  else
    R = A;

  if ( R == 0 )
    R = 1808;    
}


//------------------
  void Rand ( void )
//------------------
{
  R *= 251;

  LoadWordImm(R);
}

//-----------------
  void Max ( void )
//-----------------
{
  if ( B > A ) A = B;	
  NumPop();
}


//-----------------
  void Min ( void )
//-----------------
{
  if ( B < A ) A = B;	
  NumPop();
}


// *** Vergleichsoperationen ***


//--------------------
  void Higher ( void )
//--------------------
{
  if ( B > A ) 
    A = TRUE;	
  else
    A = FALSE;
    
  NumPop();
}

//-------------------
  void Lower ( void )
//-------------------
{
  if ( B < A ) 
    A = TRUE;	
  else
    A = FALSE;

  NumPop();
}

//------------------------
  void HigherSame ( void )
//------------------------
{
  if ( B < A ) 
    A = FALSE;	
  else
    A = TRUE;

  NumPop();
}

//-----------------------
  void LowerSame ( void )
//-----------------------
{
  if ( B > A ) 
    A = FALSE;	
  else
    A = TRUE;

  NumPop();
}


//-------------------
  void Equal ( void )
//-------------------
{
  if ( B == A ) 
    A = TRUE;	
  else
    A = FALSE;

  NumPop();  
}

//----------------------
  void NotEqual ( void )
//----------------------
{
  if ( B == A ) 
    A = FALSE;	
  else
    A = TRUE;

  NumPop();  
}



