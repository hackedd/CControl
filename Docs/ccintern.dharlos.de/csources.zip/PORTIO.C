/**********************************************************

   C-Control Betriebssystem, 68HC05B6

   Copyright (c) Conrad Electronic GmbH, Hirschau

   Datei:   portio.c
   Inhalt:  Funktionen zum Zugriff auf die Prozessorports
            im Anwenderprogramm

**********************************************************/

#include <intrpt.h>
#include "portio.h"
#include "6805\68hc05b6.h"

// Ports A, B, C und D als lineares Bitfeld

volatile BITS porta @ PADATA;
volatile BITS portb @ PBDATA;
volatile BITS portc @ PCDATA;
volatile BITS portd @ PDDATA;

BITS portadir @ PADIR;
BITS portbdir @ PBDIR;
BITS portcdir @ PCDIR;

// 16 universelle Ports aus Usersicht
volatile unsigned char near port[2] @ PBDATA;
volatile unsigned int near wordport @ PBDATA;
 
unsigned char near portdir[2] @ PBDIR;
unsigned int near wordportdir @ PBDIR;

volatile unsigned char near adc @ ADCDATA;
struct {
         int COCO: 1;
         int ADRC: 1;
         int ADON: 1;
         int reserved: 1;
         int CH: 4;
       } adcctrl @ ADCCTRL;


unsigned char near dac[2] @PLMA;



//------------------------------------------
  unsigned char GetPort ( unsigned char nr )
//------------------------------------------
{
  unsigned char i = nr / 8;           // Portindex
  unsigned char bit = nr % 8;         // Bitindex
  unsigned char mask = 1 << bit;         // Testmaske
  mask &= port[i];

  return mask;
}


//----------------------------------------------
  unsigned char GetBytePort ( unsigned char nr )
//----------------------------------------------
{
  return port[nr];
}


//---------------------------
  unsigned int GetWordPort ()
//---------------------------
{
  return wordport;
}


//-----------------------------------------------------
  void SetPort ( unsigned char nr, unsigned char data )
//-----------------------------------------------------
{
  unsigned char i = nr / 8;      // Portindex
  unsigned char bit = nr % 8;    // Bitindex
  unsigned char mask = 1 << bit;

  di();
  if ( data )
    port[i] |= mask;
  else
    port[i] &= ~mask;

  portdir[i] |= mask;    // Port als Ausgang
  ei();
}


//---------------------------------------------------------
  void SetBytePort ( unsigned char nr, unsigned char data )
//---------------------------------------------------------
{
  di();
  port[nr] = data;
  portdir[nr] = 0xFF;
  ei();
}


//--------------------------------------
  void SetWordPort ( unsigned int data )
//--------------------------------------
{
  di();
  wordport = data;
  wordportdir = 0xFFFF;
  ei();
}

//------------------------------------
  void TogglePort ( unsigned char nr )
//------------------------------------
{
  unsigned char i = nr / 8;      // Portindex
  unsigned char bit = nr % 8;    // Bitindex
  unsigned char mask = 1 << bit;
  
  port[i] ^= mask;		// Port muss bereits Ausgang sein!!
}


//-----------------------------------
  void PulsePort ( unsigned char nr )
//-----------------------------------
{
  unsigned char i = nr / 8;      // Portindex
  unsigned char bit = nr % 8;    // Bitindex
  unsigned char mask = 1 << bit;
  
  portdir[i] |= mask;    // Port als Ausgang
  port[i] ^= mask;
#asm
  NOP
  NOP
  NOP
  NOP
  NOP
  NOP
  NOP
  NOP
  NOP
  NOP
#endasm  
  port[i] ^= mask;
}

//----------------------------------------
  void DeactivatePort ( unsigned char nr )
//----------------------------------------
{
  unsigned char i = nr / 8;      // Portindex
  unsigned char bit = nr % 8;    // Bitindex
  unsigned char mask = 1 << bit;
  
  portdir[i] &= ~mask;    // Port als Eingang
}


//--------------------------------------------
  void DeactivateBytePort ( unsigned char nr )
//--------------------------------------------
{
  portdir[nr] = 0;
}


//--------------------------------
  void DeactivateWordPort ( void )
//--------------------------------
{
  wordportdir = 0;
}

//----------------------------
  int ADC ( unsigned char nr )
//----------------------------
{
#asm
	lda	9
	and	#240
	sta	9
	txa	
	and	#15
	ora	9
	sta	9
adloop	brclr	7,9,adloop
	lda	8
	clrx
	rts
#endasm
}


//-------------------------------------------------
  void DAC ( unsigned char nr, unsigned char data )
//-------------------------------------------------
{
  dac[nr] = data;
}

