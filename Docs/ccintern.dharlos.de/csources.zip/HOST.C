/**********************************************************

   C-Control Betriebssystem, 68HC05B6

   Copyright (c) Conrad Electronic GmbH, Hirschau

   Datei:   host.c
   Inhalt:  Funktionen zur	Kommunikation mit Host-PC

**********************************************************/

#include "host.h"
#include "rs232.h"
#include "eeprom.h"
#include "24C65.h"
#include "codedefs.h"
#include "portio.h"
#include "timing.h"
#include "fileio.h"
#include "6805\68hc05b6.h"
#include <intrpt.h>


// *** lokale Daten ***

static const char INFO[] = "CCTRL-BASIC Version 1.1 (20.12.96)";
static const char COPYRIGHT[] = "(C) 1996, Conrad Electronic GmbH Germany";
static const char AUTHOR[] = "Martin Foerster, CTC";


// *** lokale Prototypen ***

void SendInfo ( void );
void Program ( void );
void DumpProgram ( void );
void ProgUserCode ( void );
void DumpUserCode ( void );
void SetTime ( void );


//---------------------------
  void DispatchHostCommand ()
//---------------------------
{
  unsigned char command = RS232_GetByte();	

  switch ( command )
  {
    case CMD_GETINFO: SendInfo (); break;

    case CMD_PROGRAM: Program(); break;

    case CMD_DUMPPROG: DumpProgram(); break;

    case CMD_USERCODE: ProgUserCode(); break;

    case CMD_SETTIME: SetTime(); break;

    case CMD_DUMPFILE: DumpFile(); break;

    case CMD_DUMPUSERCODE: DumpUserCode(); break;
  }
}

//----------------
  void SendInfo ()
//----------------
{
  unsigned char i = 0;

  while ( INFO[i] )
  {
    RS232_WriteByte(INFO[i]);
    i++;
  }
  RS232_SendCR();
}


//---------------
  void Program ()
//---------------
{
  WORDSTRUCT codelen;
  unsigned char codebyte;
  
  SET_RUN_LED_ON;
  _24C65_BeginSequentialWrite(CODELEN);
    
  // code length
  codelen.byte.hi = RS232_GetByte();
  _24C65_WriteNext(codelen.byte.hi);
  RS232_WriteByte(codelen.byte.hi);
  codelen.byte.lo = RS232_GetByte();
  _24C65_WriteNext(codelen.byte.lo);
  RS232_WriteByte(codelen.byte.lo);

  // filelength = 0
  _24C65_WriteNext(0);
  _24C65_WriteNext(0);


  // code bytes
  for(; codelen.word; codelen.word-- )
  {
    codebyte = RS232_GetByte();
    _24C65_WriteNext(codebyte);
    RS232_WriteByte(codebyte);
  }

  SET_RUN_LED_OFF;
}


//-------------------
  void DumpProgram ()
//-------------------
{
  int codelen;
  
  _24C65_BeginSequentialRead(CODELEN);
  codelen = _24C65_ReadWord();
  _24C65_EndSequentialRead();

  if ( codelen == 0xFFFF )
    codelen = 1;

  RS232_SendValueAsText(codelen);  
  RS232_SendCR();
    
  _24C65_BeginSequentialRead(PROGSTART);

  for (; codelen; codelen-- ) 
    RS232_WriteByte(_24C65_ReadNext() );
	
  _24C65_EndSequentialRead();
}


//-------------------------
  void ProgUserCode( void )
//-------------------------
{
  unsigned char i;	
  unsigned char codebyte;
  unsigned char codelen;

  SET_RUN_LED_ON;
   
  // code length
  codelen = RS232_GetByte();
  RS232_WriteByte(codelen);

  if ( codelen > EESIZE )
    codelen = EESIZE;

  for ( i = 0; i < codelen; i++ )
  {
    codebyte = RS232_GetByte();	  
    EE_WriteByte(i, codebyte);
    RS232_WriteByte(codebyte);
  }

  SET_RUN_LED_OFF;
}


//--------------------------
  void DumpUserCode ( void )
//--------------------------
{
  int i;

  for ( i = 0; i < EESIZE; i++ )
    RS232_WriteByte(eeprom[i]);
}


//---------------------
  void SetTime ( void )
//---------------------
{
  sec = RS232_GetByte();
  min = RS232_GetByte();
  hour = RS232_GetByte();
  dayoftheweek = RS232_GetByte();
  day = RS232_GetByte();
  month = RS232_GetByte();
  year = RS232_GetByte();
  SetDCF77ValidFlag();
}



