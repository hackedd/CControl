/**********************************************************

   C-Control Betriebssystem, 68HC05B6

   Copyright (c) Conrad Electronic GmbH, Hirschau

   Datei:   24c65.c
   Inhalt:  Funktionen zum Zugriff auf das serielle EEPROM
            (siehe auch i2c.as)

**********************************************************/

#include "24C65.h"
#include <intrpt.h>

#include "portio.h"


/* EEPROM-Geraeteadressen bei A2=A1=A0= 0 */
#define DEVICE_READ_ADR 0xA1
#define DEVICE_WRITE_ADR 0xA0


WORDSTRUCT near adrcounter;

#define SendAddress() I2C_Start(DEVICE_WRITE_ADR);\
                      I2C_Write(adrcounter.byte.hi);\
                      I2C_Write(adrcounter.byte.lo);


//-----------------------------------------------------
  void _24C65_BeginSequentialWrite ( unsigned int adr )
//-----------------------------------------------------
{ 
  adrcounter.word = adr; 
}  


//--------------------------------------------
  void _24C65_WriteNext ( unsigned char byte )
//--------------------------------------------
{
  SendAddress();
  I2C_Write(byte);
  I2C_Stop();
  adrcounter.word++;
}


//-------------------------------------------
  void _24C65_WriteWord ( unsigned int data )
//-------------------------------------------
{
  WORDSTRUCT ws;

  ws.word = data;	
  
  SendAddress();
  I2C_Write(ws.byte.hi);
  I2C_Write(ws.byte.lo);
  I2C_Stop();
  adrcounter.word += 2;
}



//----------------------------------------------------
  void _24C65_BeginSequentialRead ( unsigned int adr )
//----------------------------------------------------
{
  adrcounter.word = adr;	
  SendAddress();
  I2C_Start(DEVICE_READ_ADR);
}


//--------------------------------------
  void _24C65_EndSequentialRead ( void ) 
//--------------------------------------
{
  I2C_ReadLast();
}

//--------------------------------------
  unsigned char _24C65_ReadNext ( void )
//--------------------------------------
{
  adrcounter.word++;	

  return I2C_Read();
}


//-------------------------------------
  unsigned int _24C65_ReadWord ( void )
//-------------------------------------
{
  WORDSTRUCT ws;

  ws.byte.hi = _24C65_ReadNext();
  ws.byte.lo = _24C65_ReadNext();

  return ws.word;
}


