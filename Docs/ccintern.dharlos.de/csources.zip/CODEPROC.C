/**********************************************************

   C-Control Betriebssystem, 68HC05B6

   Copyright (c) Conrad Electronic GmbH, Hirschau
 
   Datei:   codeproc.c
   Inhalt:  Funktionen zur Ausfuehrung des Anwenderprogramms

**********************************************************/

#include "codeproc.h"

#include "calc.h"
#include "portio.h"
#include "i2c.h"
#include "timing.h"
#include "codedefs.h"

#include "24C65.h"
#include "RS232.h"
#include "intrpt.h"
#include "eeprom.h"
#include "i2c.h"
#include "fileio.h"


// *** lokale Prototypen ***

void ProcNix ( void );
void ProcBegin ( void );
void ProcWait ( void );
void ProcGoto ( void );      // allg. Sprung und fuer IF...THEN...ELSE
void ProcIfNotGoto ( void ); // zur Verzweigung in den ELSE-Zweig bei IF...
void ProcGosub ( void );
void ProcReturn ( void );
void ProcSys ( void );
void ProcSlowMode ( void );

void ProcGetPort ( void );
void ProcGetBytePort ( void );
void ProcGetWordPort ( void );
void ProcSetPort ( void );
void ProcSetBytePort ( void );
void ProcSetWordPort ( void );

void ProcADC ( void );
void ProcDAC ( void );

void ProcLoadImm ( void );
void ProcLoadBit ( void );
void ProcLoadByte ( void );
void ProcLoadWord ( void );
void ProcStoreBit ( void );
void ProcStoreByte ( void );
void ProcStoreWord ( void );

void ProcLookup ( void );

void ProcLoadSpecialData ( void );
void ProcStoreSpecialData ( void );

void ProcSendResult ( void );
void ProcSendText ( void );
void ProcSendByte ( void );
void ProcIsByteAvail ( void );
void ProcGetByte ( void );
void ProcInput ( void );
void ProcHandshake ( void );
void ProcIsCts ( void );

void ProcFileIO ( void );
void ProcCheckEof ( void );
void ProcSetBaud ( void );
void ProcSetInterrupt ( void );
void ProcReturnInterrupt ( void );

void ProcIfByteEqualGoto ( void );
void ProcIfWordEqualGoto ( void );
void ProcAddStoreByteAndGoto ( void );
void ProcAddStoreWordAndGoto ( void );

void ProcTogglePort ( void );
void ProcPulsePort ( void );
void ProcDeactivatePort ( void );
void ProcDeactivateBytePort ( void );

// Struktur fuer den SYS-Befehl
struct { char jmp; int adr; } near jumpstruct;


// Ruecksprung fuer GOSUB-RETURN

unsigned int near retadr1;
unsigned int near retadr2;
unsigned int near retadr3;
unsigned int near retadr4;

// BASIC-Sprungadresse und Ruecksprung fuer IRQs
unsigned int near irqadr;
unsigned int near irqretadr;


// *** Sprungtabelle ***

const CODEPROC proc[] =
{
ProcNix,		// 0
  ProcBegin,
  ProcWait,	
  ProcGoto,	
  ProcIfNotGoto,	
  ProcGosub,	
  ProcReturn,	
  ProcReturnInterrupt,	
  ProcSys,
  ProcSlowMode,	

  ProcGetPort,		// 10
  ProcGetBytePort,
  ProcGetWordPort,
  ProcSetPort,
  ProcSetBytePort,
  ProcSetWordPort,
  ProcADC,
  ProcDAC,
ProcNix, 
ProcNix,

  ProcLoadImm,		// 20
  ProcLoadBit,
  ProcLoadByte,
  ProcLoadWord,
  ProcStoreBit,
  ProcStoreByte,
  ProcStoreWord,
  ProcLookup,
  ProcLoadSpecialData,
  ProcStoreSpecialData,	

  ProcSendResult,	// 30
  ProcSendText,	
  ProcSendByte,	
  ProcIsByteAvail,	
  ProcGetByte,	
  ProcInput,	
  ProcHandshake,
  ProcIsCts,
ProcNix,	
ProcNix,

  Not,		// 40
  And,
  Nand,
  Or,
  Nor,
  Xor,
  Shl,
  Shr,
  Randomize,	
  Rand,	

  Neg,		// 50
  Add,
  Sub,
  Mul,
  Div,
  Mod,
  Abs,
  Sqr,
  Max,
  Min,

  Higher,		// 60
  HigherSame,
  Lower,
  LowerSame,
  Equal,
  NotEqual,
  Sgn,
ProcNix,
ProcNix,
ProcNix,

  ProcFileIO,		// 70
  ProcCheckEof,
  ProcSetBaud,
  ProcSetInterrupt,
  ProcIfByteEqualGoto,
  ProcIfWordEqualGoto,
  ProcAddStoreByteAndGoto,
  ProcAddStoreWordAndGoto,
ProcNix,
ProcNix,
  ProcTogglePort,
  ProcPulsePort,
  ProcDeactivatePort,
  ProcDeactivateBytePort,
  DeactivateWordPort
};


// *** Funktionen ***


//-------------------------
  void InitUserJmp ( void )
//-------------------------
{
  jumpstruct.jmp = 0xCC; //JMP-Befehl
  jumpstruct.adr = 0;
   
  retadr1 = 0;
  retadr2 = 0;
  retadr3 = 0;
  retadr4 = 0;

  irqadr = 0;
  irqretadr = 0;
}	


//---------------------
  void ProcNix ( void )
//---------------------
{
}


//-----------------------
  void ProcBegin ( void )
//-----------------------
{
  ClearRegs();	
}

//----------------------
  void ProcWait ( void )
//----------------------
{
  SET_RUN_LED_OFF;
  Wait(GetResult());
  SET_RUN_LED_ON;
}

//----------------------
  void ProcGoto ( void )
//----------------------
{
  unsigned int adr = _24C65_ReadWord();
  _24C65_EndSequentialRead();	
  _24C65_BeginSequentialRead(adr);	
}


//---------------------------
  void ProcIfNotGoto ( void )
//---------------------------
{
  unsigned int adr = _24C65_ReadWord();

  if ( !GetResult() )
  {
    _24C65_EndSequentialRead();	
    _24C65_BeginSequentialRead(adr);	
  }
}

//-------------------------
  void IfEqualGoto ( void )
//-------------------------
{
  unsigned int adr = _24C65_ReadWord();	 

  if (DirectCompare())	
  {
    _24C65_EndSequentialRead();	
    _24C65_BeginSequentialRead(adr);	
  }
}

//---------------------------------
  void ProcIfByteEqualGoto ( void )
//---------------------------------
{
  LoadByte(_24C65_ReadNext());
  IfEqualGoto();	
}  

//---------------------------------
  void ProcIfWordEqualGoto ( void )
//---------------------------------
{
  LoadWord(_24C65_ReadNext());
  IfEqualGoto();	
}  

//-------------------------------------
  void ProcAddStoreByteAndGoto ( void )
//-------------------------------------
{
  unsigned char index = _24C65_ReadNext();	
  Add();
  StoreByte(index);
  ProcGoto();
}

//-------------------------------------
  void ProcAddStoreWordAndGoto ( void )
//-------------------------------------
{
  unsigned char index = _24C65_ReadNext();	
  Add();
  StoreWord(index);
  ProcGoto();
}
 
//-------------------------------
  void Gosub ( unsigned int adr )
//-------------------------------
{
  if ( retadr1 == 0 )
    retadr1 = _24C65_WhereNow();
  else if ( retadr2 == 0 )
    retadr2 = _24C65_WhereNow();
  else if ( retadr3 == 0 )
    retadr3 = _24C65_WhereNow();
  else if ( retadr4 == 0 )
    retadr4 = _24C65_WhereNow();

  _24C65_EndSequentialRead();	
  _24C65_BeginSequentialRead(adr);	
}
 
//-----------------------
  void ProcGosub ( void )
//-----------------------  
{
  Gosub(_24C65_ReadWord());
}

//------------------------
  void ProcReturn ( void )
//------------------------
{
  if ( retadr4 )
  { 
    _24C65_EndSequentialRead();	
    _24C65_BeginSequentialRead(retadr4);	
    retadr4 = 0;
  }
  else if ( retadr3 )
  {
    _24C65_EndSequentialRead();	
    _24C65_BeginSequentialRead(retadr3);	
    retadr3 = 0;
  }
  else if ( retadr2 )
  {
    _24C65_EndSequentialRead();	
    _24C65_BeginSequentialRead(retadr2);	
    retadr2 = 0;
  }
  else if ( retadr1 )
  {
    _24C65_EndSequentialRead();	
    _24C65_BeginSequentialRead(retadr1);	
    retadr1 = 0;
  }
}

//---------------------
  void ProcSys ( void )
//---------------------
{
  jumpstruct.adr = _24C65_ReadWord();	
#asm 
   JSR _jumpstruct
#endasm
}  

//--------------------------
  void ProcSlowMode ( void )
//--------------------------
{
  if ( _24C65_ReadNext() ) 
    SetSlowModeOn();
  else 
    SetSlowModeOff();	
}

//-------------------------
  void ProcGetPort ( void )
//-------------------------
{
  LoadBitImm(GetPort(_24C65_ReadNext()));
}
 
//-----------------------------
  void ProcGetBytePort ( void )
//-----------------------------
{
  LoadByteImm(GetBytePort(_24C65_ReadNext()));
}
 
//-----------------------------
  void ProcGetWordPort ( void )
//-----------------------------
{
  LoadWordImm(GetWordPort());
}
 
//-------------------------
  void ProcSetPort ( void )
//-------------------------
{
  SetPort(_24C65_ReadNext(), GetResult());
}
 
//-----------------------------
  void ProcSetBytePort ( void )
//-----------------------------
{
  SetBytePort(_24C65_ReadNext(), (unsigned char) GetResult());
}
 
//----------------------------
 void ProcSetWordPort ( void )
//----------------------------
{
  SetWordPort(GetResult());
}
 

//---------------------
  void ProcADC ( void )
//---------------------
{
  LoadWordImm(ADC(_24C65_ReadNext()));	
}
 
//---------------------
  void ProcDAC ( void )
//---------------------
{
  DAC(_24C65_ReadNext(), (unsigned char) GetResult());	
}
 
//----------------------------
  void ProcTogglePort ( void )
//----------------------------
{
  TogglePort(_24C65_ReadNext());
}


//---------------------------
  void ProcPulsePort ( void )
//---------------------------
{
  PulsePort(_24C65_ReadNext());
}
  

//--------------------------------
  void ProcDeactivatePort ( void )
//--------------------------------
{
  DeactivatePort(_24C65_ReadNext());
}

//------------------------------------
  void ProcDeactivateBytePort ( void )
//------------------------------------
{
  DeactivateBytePort(_24C65_ReadNext());	
}


//*************************************

//-------------------------
  void ProcLoadImm ( void )
//-------------------------
{
  LoadWordImm((int)_24C65_ReadWord());
}
 
//-------------------------
  void ProcLoadBit ( void )
//-------------------------
{
  LoadBit(_24C65_ReadNext());	
}
 
//--------------------------
  void ProcLoadByte ( void )
//--------------------------
{
  LoadByte(_24C65_ReadNext());	
}
 
//--------------------------
  void ProcLoadWord ( void )
//--------------------------
{
  LoadWord(_24C65_ReadNext());	
}
 
//--------------------------
  void ProcStoreBit ( void )
//--------------------------
{
  StoreBit(_24C65_ReadNext());	
}
 
//---------------------------
  void ProcStoreByte ( void )
//---------------------------
{
  StoreByte(_24C65_ReadNext());	
}
 
//---------------------------
  void ProcStoreWord ( void )
//---------------------------
{
  StoreWord(_24C65_ReadNext());	
}
 

//------------------------
  void ProcLookup ( void )
//------------------------
{
  unsigned int adrbuf;
  unsigned int tableadr = _24C65_ReadWord();

  adrbuf = _24C65_WhereNow(); 
  
  _24C65_EndSequentialRead();
  _24C65_BeginSequentialRead( tableadr + 2 * GetResult());

  LoadWordImm((int)_24C65_ReadWord());
  _24C65_EndSequentialRead();
  
  _24C65_BeginSequentialRead(adrbuf);
}
 

//---------------------------------
  void ProcLoadSpecialData ( void )
//---------------------------------
{
  unsigned char id = _24C65_ReadNext();

  di();
  	
  switch ( id )	
  {
    case SPECIALDATA_YEAR:
      LoadByteImm(year);   
      break;	  
      
    case SPECIALDATA_MONTH:
      LoadByteImm(month);   
      break;	  
      
    case SPECIALDATA_DAY:
      LoadByteImm(day);   
      break;	  
      
    case SPECIALDATA_DAYOWEEK:
      LoadByteImm(dayoftheweek);
      break;	  
      
    case SPECIALDATA_HOUR:
      LoadByteImm(hour);
      break;	  
      
    case SPECIALDATA_MIN:
      LoadByteImm(min);
      break;
      	  
    case SPECIALDATA_SEC:
      LoadByteImm(sec);
      break;	  
      
    case SPECIALDATA_TIMER:
      di();   
      LoadWordImm(GetTimer());
      ei();
      break;	  

    case SPECIALDATA_FREQHZ:
      LoadWordImm(GetFreqHz());  
      break;

    case SPECIALDATA_FREQHZ2:
      LoadWordImm(GetFreqHz2());  
      break;

    case SPECIALDATA_FILEFREE:
      LoadWordImm(GetFreeFileSpace());  
      break;

    case SPECIALDATA_FILELEN:
      LoadWordImm(GetFileLength());  
      break;
  }
  
  ei();
}
 
//----------------------------------
  void ProcStoreSpecialData ( void )
//----------------------------------
{
  unsigned char id = _24C65_ReadNext();
  int result = GetResult();

  di();
  	
  switch ( id )	
  {
    case SPECIALDATA_YEAR:
      year = (unsigned char) result;   
      break;	  
      
    case SPECIALDATA_MONTH:
      month = (unsigned char) result;   
      break;	  
      
    case SPECIALDATA_DAY:
      day = (unsigned char) result;
      break;	  
      
    case SPECIALDATA_DAYOWEEK:
      dayoftheweek = (unsigned char) result;
      break;	  
      
    case SPECIALDATA_HOUR:
      hour = (unsigned char) result;
      break;	  
      
    case SPECIALDATA_MIN:
      min = (unsigned char) result;
      break;
      	  
    case SPECIALDATA_SEC:
      sec = (unsigned char) result;
      break;	  
      
    case SPECIALDATA_USERTICKS:
      SetUserTicks(result);
      break;	  
  }

  ei();
}
 


//----------------------
  void ProcSendResult ()
//----------------------
{
  RS232_SendValueAsText(GetResult());
}


//--------------------
  void ProcSendText ()
//--------------------
{
  unsigned char send;

  while ( send = _24C65_ReadNext() )
    RS232_WriteByte(send);
}


//--------------------
  void ProcSendByte ()
//--------------------
{
  RS232_WriteByte((unsigned char)GetResult());
}


//-----------------------
  void ProcIsByteAvail ()
//-----------------------
{
  LoadBitImm(RS232_IsByteAvail());	
}

//-------------------
  void ProcGetByte ()
//-------------------
{
  LoadByteImm(RS232_GetByte());
}

//---------------------------
  void ProcHandshake ( void )
//---------------------------
{
  if (_24C65_ReadNext())
    EnableRtsCts();
  else
  {
    DisableRtsCts();
    RTS();
  }	
}  

//-----------------------
  void ProcIsCts ( void )
//-----------------------
{
  LoadBitImm(RS232_IsCTS());	
}

//-----------------
  void ProcInput ()
//-----------------
{
  int i;
  unsigned char byte;
  unsigned char neg;

  i = 0;
  neg = 0;

  do
  {
    byte = RS232_GetByte();
    
    if ( byte == '-' )
      neg = 1;
    else if (( byte >= '0' ) && ( byte <= '9' ))
    {
      i *= 10;
      i += byte - '0';
    }
  }
  while ( byte != ASCII_CR );

  if ( neg ) 
    i = -i;

  LoadWordImm(i);
}


// *** File IO ***

//------------------------
  void ProcFileIO ( void )
//------------------------
{
  unsigned char iocode = _24C65_ReadNext();
  unsigned int adrbuf = _24C65_WhereNow();

  _24C65_EndSequentialRead();

  switch ( iocode )
  {
    case FILE_OPENFORREAD:	OpenFileForRead(); break;
    case FILE_OPENFORWRITE: 	OpenFileForWrite(); break;
    case FILE_OPENFORAPPEND: 	OpenFileForAppend(); break;
    case FILE_CLOSE: 	CloseFile(); break;
    case FILE_PRINT: 	WriteFile(GetResult()); break;
    case FILE_INPUT: 	LoadWordImm((int)ReadFile()); break;
  } 

  _24C65_BeginSequentialRead(adrbuf);
}

  
//-------------------------
  void ProcCheckEof ( void )  
//-------------------------
{
  LoadBitImm(IsEof()); 
}


//-------------------------
  void ProcSetBaud ( void )
//-------------------------
{
  RS232_SetBaud(_24C65_ReadNext());
}  


//------------------------------
  void ProcSetInterrupt ( void )
//------------------------------
{
  irqadr = _24C65_ReadWord();
}

//---------------------------
  void UserInterrupt ( void )
//---------------------------
{
  if ( irqadr )
  {	
    irqretadr = _24C65_WhereNow();
    _24C65_EndSequentialRead();	
    _24C65_BeginSequentialRead(irqadr);	
  }
}

//---------------------------------
  void ProcReturnInterrupt ( void )
//---------------------------------
{
  if ( irqretadr )
  {
    _24C65_EndSequentialRead();	
    _24C65_BeginSequentialRead(irqretadr);	
    irqretadr = 0;
  }
}

