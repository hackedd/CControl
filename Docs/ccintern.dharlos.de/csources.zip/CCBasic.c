/**********************************************************

   C-Control Betriebssystem, 68HC05B6

   Copyright (c) Conrad Electronic GmbH, Hirschau

   Datei:   ccbasic.c
   Inhalt:  Hauptmodul mit Main-Funktion ( =Einsprung nach
            RESET)

**********************************************************/


#include "24C65.h"
#include "codedefs.h"
#include "codeproc.h"
#include "portio.h"
#include "calc.h"
#include "rs232.h"
#include "host.h"
#include "timing.h"
#include "i2c.h"
#include "6805\68hc05b6.h"
#include <intrpt.h>


extern char IRQPTR;
extern char CAPPTR;
extern char CMPPTR;
extern char OFLPTR;


// *** lokale Prototypen ***


// Run-Funktion zum Ausfuehren des Anwenderprogramms
void Run ( void );

unsigned char near token;
 


//-----------
  void Run ()
//-----------
{ 

  SET_ACTIVE_LED_ON;
  SET_RUN_LED_ON;
  SetActiveFlag();

  _24C65_BeginSequentialRead(PROGSTART); 
  ClrUserInterruptFlag();


  // Programmausfuehrung
  for(;;)
  {
    if ( bDoUserInterrupt && bNotInUserInterrupt )
    {
      ClrUserInterruptFlag();
      UserInterrupt();  	     
    }
    	  
    token = _24C65_ReadNext();

    if ( token == CODE_END ) 
      break;
    else if ( token <= ((unsigned char)LASTCODE) )
      (proc[token])();
    else break;  
  }     

  _24C65_EndSequentialRead();	
  
  SET_ACTIVE_LED_OFF;
  SET_RUN_LED_OFF;
  ClrActiveFlag();
  DisableRtsCts();
  RTS();
}




//-------
  main ()
//-------
{
  ROM_VECTOR(SCI_VEC, HandleSCI);
  ROM_VECTOR(TMRCOMP_VEC, TMRCMP);
  ROM_VECTOR(TMRCAP_VEC, TMRCAP);
  ROM_VECTOR(TMROVFL_VEC, TMROFL);
  ROM_VECTOR(IRQ_VEC, IRQ);

  di();

  IRQPTR = 0;
  CAPPTR = 0;
  CMPPTR = 0;
  OFLPTR = 0;

  InitTiming();
  I2C_Init();
  RS232_Setup();

  ClearFlags();
  ACTIVATE_ACTIVE_LED;
  ACTIVATE_RUN_LED;

  // Initialisierungen (calc.c)
  ClearData();
  ClearRegs();

  InitUserJmp();

  asm("BSET 5,$C"); // negative egde IRQ

  
  ei();

  for(;;)
  {
    asm("WAIT");  

    if ( IS_START_BUTTON_PRESSED )
      Run();

    else if ( RS232_IsByteAvail() )
      DispatchHostCommand();
  }
}

