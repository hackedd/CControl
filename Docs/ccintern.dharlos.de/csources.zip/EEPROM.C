/**********************************************************

   C-Control Betriebssystem, 68HC05B6

   Copyright (c) Conrad Electronic GmbH, Hirschau

   Datei:   eeprom.c
   Inhalt:  Funktionen zum Schreiben in das On-Chip-EEPROM

**********************************************************/


#include "eeprom.h"
#include "6805\68hc05b6.h"

void Delay ( void );

/* Serial Communications Control Register 1 */

union {
		  unsigned char all;
		  struct  {
						int : 1;
						int : 1;
						int : 1;
						int : 1;
						int : 1;
						int E1ERA: 1;
						int E1LAT: 1;
						int E1PGM: 1;
					 } bit;
		} eectrl @ EECTRL;

unsigned char eeprom[EESIZE] @ EEPROM;


//--------------------------------------------------------
  void EE_WriteByte (unsigned char i, unsigned char byte )
//--------------------------------------------------------
{
  asm("sei");
  // alten Inhalt loeschen
  eectrl.bit.E1LAT = 1;
  eectrl.bit.E1ERA = 1;
  
  eeprom[i] = 0xFF;
  eectrl.bit.E1PGM = 1;
  Delay();
  eectrl.bit.E1LAT = 0;

  // neuen Inhalt eintragen
  eectrl.bit.E1LAT = 1;
  eeprom[i] = byte;
  eectrl.bit.E1PGM = 1;
  Delay();
  eectrl.bit.E1LAT = 0;
  asm("cli");
}


//-------------
  void Delay ()
//-------------
{
  unsigned int n = 6000;
  while (n--)
    asm("NOP");
}


