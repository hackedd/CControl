/**********************************************************

   C-Control Betriebssystem, 68HC05B6

   Copyright (c) Conrad Electronic GmbH, Hirschau

   Datei:  FILEIO.C

**********************************************************/

#include "fileio.h"
#include "24C65.h"
#include "RS232.h"


unsigned int near filestart;
unsigned int near fileoff;
unsigned int near filelen;



//-----------------------------
  void OpenFileForRead ( void )
//-----------------------------
{
  _24C65_BeginSequentialRead(CODELEN);
  filestart = _24C65_ReadWord() + PROGSTART;
  filelen = _24C65_ReadWord();
  _24C65_EndSequentialRead();

  fileoff = 0;
}

//------------------------------
  void OpenFileForWrite ( void )
//------------------------------
{
  _24C65_BeginSequentialRead(CODELEN);
  filestart = _24C65_ReadWord() + PROGSTART;
  _24C65_EndSequentialRead();

  filelen = 0;
  fileoff = 0;
}

//-------------------------------
  void OpenFileForAppend ( void )
//-------------------------------
{
  _24C65_BeginSequentialRead(CODELEN);
  filestart = _24C65_ReadWord() + PROGSTART;
  filelen = _24C65_ReadWord();
  _24C65_EndSequentialRead();

  fileoff = filelen;
}

//-----------------------
  void CloseFile ( void )
//-----------------------
{
  _24C65_BeginSequentialWrite(FILELEN);
  _24C65_WriteWord(filelen);
}


//------------------------------------
  void WriteFile ( unsigned int data )
//------------------------------------
{
  _24C65_BeginSequentialWrite(filestart+fileoff);
  _24C65_WriteWord(data);

  fileoff += 2;
  filelen = fileoff;
} 

//------------------------------
  unsigned int ReadFile ( void )
//------------------------------
{
  unsigned int data;

  _24C65_BeginSequentialRead(filestart+fileoff);
  data = _24C65_ReadWord();
  _24C65_EndSequentialRead();

  fileoff += 2;

  return data;
}

//----------------------------
  unsigned char IsEof ( void )
//----------------------------
{
  return ( fileoff >= filelen );
}

//--------------------------------------
  unsigned int GetFreeFileSpace ( void )
//--------------------------------------
{
  return ( (_24C65_LASTBYTE - filestart - filelen) / 2 );
}

//----------------------
  void DumpFile ( void )
//----------------------
{
  OpenFileForRead();

  RS232_SendValueAsText(filelen);
  RS232_SendCR();

  _24C65_BeginSequentialRead(filestart);

  while ( fileoff < filelen )
  {
    RS232_SendValueAsText((int)_24C65_ReadWord());
    RS232_SendCR();
  }

  _24C65_EndSequentialRead();

  // close nicht noetig, da filelen unveraendert
}

