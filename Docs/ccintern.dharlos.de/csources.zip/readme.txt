C-Control Quelltexte
====================

Wir veroeffentlichen die Quelltexte zum Betriebssystem
des C-Control Steuercomputers mit dem Ziel, die internen 
Ablaeufe des Systems fuer unsere Kunden vollstaendig 
transparent zu gestalten. Mit Kenntnis der Systemzusammenhaenge 
und der Moeglichkeit, Assemblerroutinen in C-Control/BASIC 
einzubinden, sollte jeder interessierte C-Control-Anwender 
in der Lage sein, auch spezielle Problemstellungen zu loesen.

Die Quelltexte werden in vorliegender Form bereitgestellt. 
Zum Verstaendnis der Quelltexte sind Kenntnisse der 
Programmiersprache C und der 68HC05-Assemblerprogrammierung 
erforderlich.

Zu den C-Control Quelltexten gewaehrt Conrad Electronic
keinerlei Support! Bitte haben Sie Verstaendnis, dass ab 
Veroeffentlichung der Quelltexte auch keinerlei Anfragen mehr 
bearbeitet werden koennen, die im Zusammenhang mit der 
Realisierung von Anwendungen stehen, die Massnahmen ausserhalb 
der Standard-Spezifikationen von C-Control/BASIC und 
C-Control/plus erfordern.

Die C-Control Quelltexte sind Eigentum der Conrad Electronic GmbH.


Conrad Electronic GmbH
Hirschau, den 19.05.1998


